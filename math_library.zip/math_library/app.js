var mathlib = require('./mathlib')();

console.log(mathlib.add(1,2));
console.log(mathlib.random(5,50));
